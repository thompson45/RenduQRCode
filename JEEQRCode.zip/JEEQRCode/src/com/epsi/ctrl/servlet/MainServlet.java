package com.epsi.ctrl.servlet;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.epsi.mdl.dao.ServiceDAO;
import com.epsi.mdl.entity.UtilisateurEntity;

/**
 * Servlet principale lors de l'accès au site
 * @author Baptiste
 *
 */
public class MainServlet extends HttpServlet
{
	/**
	 * Attribut généré par HttpServlet
	 */
	private static final long serialVersionUID = 8263548040397909955L;
	
	/**
	 * 
	 */
	
	public UtilisateurEntity user = new UtilisateurEntity();
	
	/**
	 * Variable contenant la session
	 */
	public HttpSession session;
	
	/**
	 * Variable permettant de n'appeler qu'une seule fois le
	 * 'this.getServletContext().getRequestDispatcher().forward();'
	 *  pour éviter de lever une exception
	 */
	private boolean dejaCall;
	
  
	/**
	 * Initialisation de la connexion à la base de données
	 * @see Servlet#init(ServletConfig)
	 */
	@Override
	public void init() throws ServletException
	{
		user = new UtilisateurEntity();
	}
	
	/**
	 * Gère l'action a effectuer par la Servlet en fonction de la donnée réceptionnée
	 *  @param request Requête
	 * @return Retourne l'action a effectuer
	 */
	private String gestionAction(HttpServletRequest request)
	{
		String action 			= null;
		String conn				= request.getParameter("conn");
		String deconn			= request.getParameter("deconn");
		String service_creation = request.getParameter("service_creation");
		
		if(conn != null && conn != "")							{action = "connexion";}
		
		if(deconn != null && deconn != "")						{action = "deconnexion";}
		
		if(service_creation != null && service_creation != "")	{action = "service_creation";}
		
		if(action == null || action == "")						{action = "";session.setAttribute("message", "");}

		session.setAttribute("action", action);
		System.out.println("[Action : '"+action+"']");
		return action;
	}
	
	/**
	 * Permet d'appeler une page appartenant au site
	 * @param page Nom de la page (ex : 'index.jsp')
	 * @param request 
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void call(String page, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try
		{
			this.getServletContext().getRequestDispatcher("/QRCode/"+page).forward(request, response);
			System.out.println("[Page : '/QRCode/"+page+"']");
		}
		catch(Exception E)
		{
			System.out.println(E.getMessage());
		}
		dejaCall = true;
	}

	/**
	 * Procédure permettant de contrôles les actions du site
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		dejaCall = false;
		session = request.getSession(true);
		session.setAttribute("session", "");
		if((UtilisateurEntity)session.getAttribute("user") == null)
		{
			request.getSession(true).setAttribute("user",user);
		}
		else
		{
			user = (UtilisateurEntity)request.getSession(true).getAttribute("user");
		}
		
		if(user.getId() == -1)
		{
			user.destroy();
			session.setAttribute("user",user);
		}
		
		String action = gestionAction(request);
		
		if (action != null && action != "")
		{
			// Connexion
			if (action.equalsIgnoreCase("connexion"))
			{
				try
				{
					doAuthentification(request, response);
					if(user.getId() != -1)
					{
						call("service.jsp",request,response);
					}
				}
				catch (Exception e)
				{
					System.out.println("Erreur au niveau de l'action '"+action+"'");
				}			
			}
			else
			{
				if(user.getId() != -1)
				{
					// Déconnexion
					if (action.equalsIgnoreCase("deconnexion"))
					{
						try
						{
							doDeconnexion(request, response);
							call("index.jsp",request,response);
						}
						catch (Exception e)
						{
							System.out.println("Erreur au niveau de l'action '"+action+"'");
						}			
					}
				
					// Création service
					if (action.equalsIgnoreCase("service_creation"))
					{
						try
						{
							doServiceCreation(request, response);
							call("service.jsp",request,response);
						}
						catch (Exception e)
						{
							System.out.println("Erreur au niveau de l'action '"+action+"'");
						}			
					}
					else
					{
						session.setAttribute("service",null);
					}
				}
				else
				{
					call("index.jsp",request,response);
				}
			}
		}
		
		// Si pas de page précisée : renvoie à la même page
		if(!dejaCall)
		{
			call("index.jsp",request,response);
		}
	}

	/**
	 * Permet à un utilisateur de s'authentifier
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAuthentification(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try
		{
			UtilisateurEntity userTest = new UtilisateurEntity(-1,request.getParameter("user"),request.getParameter("pass"));
			
			if(userTest.getNom() != "" && userTest.getMdp() != "")
			{
				if(userTest.select())
				{
					user = userTest;
					session.setAttribute("user", user);
					session.setAttribute("message", "Vous êtes connecté en tant que "+user.getNom());
				}
				else
				{
					user.destroy();
					session.setAttribute("user", user);
					session.setAttribute("message", "Combinaison login/mdp incorrect");
				}
			}
			else
			{
				session.setAttribute("message", "Veuillez renseigner les champs de connexion");
			}
		}
		catch (Exception E)
		{
			System.out.println("Problème au niveau de la requête d'authentification");
			session.setAttribute("message", "Erreur à la connexion à la base de données");
		}
	}
	
	/**
	 * Permet à un utilisateur de se déconnecter
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doDeconnexion(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		user.destroy();
		session.setAttribute("user", user);
		session.setAttribute("message", "Déconnexion réussie !");
	}
	
	/**
	 * Permet à un utilisateur de créer un service
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doServiceCreation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		session.setAttribute("service", new ServiceDAO(-1,(String)request.getParameter("name"),(String)request.getParameter("description"),0,(int)session.getAttribute("idUser")));
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request,response);
	}
}