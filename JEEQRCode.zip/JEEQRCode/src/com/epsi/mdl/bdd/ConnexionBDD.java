package com.epsi.mdl.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe permettant à se connecter à une base de donnée via JDBC
 * @author Baptiste
 *
 */
public class ConnexionBDD
{
	/**
	 * Objet connection permettant d'effectuer des requêtes
	 */
	private static Connection CONNECTION ;

	/**
	 * Unique constructeur vide de ConnexionBDD
	 */
	public ConnexionBDD()
	{
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/qrcode";
		String login = "root";
		String password = "";

		// Driver
		try
		{
	       	Class.forName(driver);
	       	System.out.println("Driver OK");
		}
		catch(ClassNotFoundException E)
	    {
			System.out.println("Problème au chargement du driver");
			System.out.println(E.getMessage());
			System.out.println(E.getCause());
	    }
		
		// Connexion
		try
		{
			CONNECTION = DriverManager.getConnection(url, login, password);
		    System.out.println("Connexion établie");
		}
		catch(SQLException E)
		{
		    System.out.println("Problème de connexion");
			System.out.println(E.getMessage());
			System.out.println(E.getCause());
		}
	}

	/**
	 * @return the CONNECTION
	 */
	public static Connection getCONNECTION()
	{
		return CONNECTION;
	}
}
