package com.epsi.mdl.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Classe permettant de gérer la bdd des services
 * @author Baptiste
 *
 */
@Entity
@Table(name="service")
public class ServiceEntity implements Serializable
{	
	/**
	 * Attribut généré par la Sérialization
	 */
	private static final long serialVersionUID = 7710122618006840192L;
	
	/**
	 * Clé primaire
	 */
	@Id
	@Column(name="id")
	private int id;

	/**
	 * Nom du service
	 */
	@Column(name="name")
	private String nom;

	/**
	 * Description du service
	 */
	@Column(name="description")
	private String description;

	/**
	 * Nombre de fois qu'une personne à utilisé ce service
	 */
	@Column(name="vote")
	private int vote;
	
	/**
	 * id de l'utilisateur créateur du service
	 */
	@Column(name="idUser")
	private int idUser;

	/**
	 * Constructeur vide de Service
	 */
	public ServiceEntity()
	{
		super();
	}

	/**
	 * Constructeur paramétrer de Service
	 * @param id
	 * @param name
	 * @param description
	 * @param vote
	 */
	public ServiceEntity(int id, String nom, String description, int vote, int idUser)
	{
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.vote = vote;
		this.idUser = idUser;
	}

	/**
	 * @return the id
	 */
	public int getId()
	{
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getNom()
	{
		return nom;
	}

	/**
	 * @param name the name to set
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * @return the description
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * @return the vote
	 */
	public int getVote()
	{
		return vote;
	}

	/**
	 * @param vote the vote to set
	 */
	public void setVote(int vote)
	{
		this.vote = vote;
	}

	/**
	 * @return the idUser
	 */
	public int getIdUser()
	{
		return idUser;
	}

	/**
	 * @param idUser the idUser to set
	 */
	public void setIdUser(int idUser)
	{
		this.idUser = idUser;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
}
