package com.epsi.mdl.entity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

/**
 * Classe permettant de gérer le QRCode
 * @author Baptiste
 *
 */
public class QRCodeEntity {
	private String code;
	private static int size = 400;
	//private static String path = "C:/Users/Baptiste/Desktop/Java/JEEQRCode/WebContent/QRCode/img/qrcode.png";
	private static String path = "C:/Users/Baptiste/Desktop/Java/JEEQRCode/WebContent/qrcode.png";

	/**
	 * 
	 */
	public QRCodeEntity() {
		super();
	}

	/**
	 * @param code
	 */
	public QRCodeEntity(String code) {
		super();
		this.code = code;
	}
	
	/**
	 * Genere l'image pour le QRCode
	 */
	public void build()
	{
		try {
			BitMatrix bitMatrix = new QRCodeWriter().encode(code, BarcodeFormat.QR_CODE, size, size);
			FileOutputStream fileOutputStream;
			fileOutputStream = new FileOutputStream(new File(path));
			MatrixToImageWriter.writeToStream(bitMatrix, "png", fileOutputStream);
	        fileOutputStream.close();
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * @return the path
	 */
	public String getPath()
	{
		return QRCodeEntity.path;
	}
	
}
