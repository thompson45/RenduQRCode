package com.epsi.mdl.entity;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.epsi.mdl.bdd.ConnexionBDD;
import com.mysql.jdbc.PreparedStatement;

/**
 * Classe permettant de gérer la bdd des utilisateurs 
 * @author Baptiste
 *
 */
@Entity
@Table(name="utilisateur")
public class UtilisateurEntity implements Serializable
{
	/**
	 * Attribut généré par la Sérialization
	 */
	private static final long serialVersionUID = 7710122618006840191L;
	
	/**
	 * Connexion à la BDD
	 */
	private ConnexionBDD CONNEXION;
	
	/**
	 * Clé primaire
	 */
	@Id
	@Column(name="id")
	private int id;

	/**
	 * Nom de l'utilisateur
	 */
	@Column(name="name")
	private String nom;

	/**
	 * Mot de passe de l'utilisateur
	 */
	@Column(name="mdp")
	private String mdp;
	
	/**
	 * Constructeur vide de l'utilisateur
	 */
	public UtilisateurEntity()
	{
		super();
		if(CONNEXION == null)
		{
			CONNEXION = new ConnexionBDD();
		}
		this.id = -1;
		this.nom = "";
		this.mdp = "";
	}

	/**
	 * Constructeur paramétré de l'utilisateur 
	 * @param id
	 * @param name
	 * @param mdp
	 */
	public UtilisateurEntity(int id, String nom, String mdp)
	{
		super();
		if(CONNEXION == null)
		{
			CONNEXION = new ConnexionBDD();
		}
		this.id = id;
		this.nom = nom;
		this.mdp = mdp;
	}
	
	/**
	 * Vérifie l'utilisateur
	 * @return Retourne si la sélection s'est bien déroulé 
	 * @throws SQLException
	 */
	public boolean select() throws SQLException
	{
		String requete = "select id, name, mdp from utilisateur where name = ? and mdp = ?";
		try
		{
			PreparedStatement preparedStatement = (PreparedStatement) ConnexionBDD.getCONNECTION().prepareStatement(requete);
			preparedStatement.setString(1, this.nom);
			preparedStatement.setString(2, this.mdp);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				this.id 	= resultSet.getInt(1);
				this.nom 	= resultSet.getString(2);
				this.nom 	= resultSet.getString(3);
				return true;
			}
		}
		catch (Exception e)
		{
			System.out.println("Erreur dans la requete de l'authentfication");
		}
		return false;
	}
	
	/**
	 * Permet de réinitiliser les variables (permet de ne pas instancier à nouveau l'objet)
	 */
	public void destroy()
	{
		this.id = -1;
		this.nom = "";
		this.mdp = "";
	}
	
	/**
	 * @return the id
	 */
	public int getId()
	{
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id)
	{
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getNom()
	{
		return nom;
	}
	/**
	 * @param name the name to set
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}
	/**
	 * @return the mdp
	 */
	public String getMdp()
	{
		return mdp;
	}
	/**
	 * @param mdp the mdp to set
	 */
	public void setMdp(String mdp)
	{
		this.mdp = mdp;
	}
}
