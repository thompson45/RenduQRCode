package com.epsi.mdl.dao;

/**
 * Classe permettant de gérer la DAO des services
 * @author Baptiste
 *
 */
public class ServiceDAO
{
		
	/**
	 * Clé primaire
	 */
	private int id;
	
	/**
	 * Nom du service
	 */
	private String nom;
	
	/**
	 * Description du service
	 */
	private String description;
	
	/**
	 * Nombre de fois qu'une personne à utilisé ce service
	 */
	private int vote;
	
	/**
	 * id de l'utilisateur créateur du service
	 */
	private int idUser;

	/**
	 * Constructeur vide de Service
	 */
	public ServiceDAO()
	{
		super();
	}

	/**
	 * Constructeur paramétré de Service
	 * @param id
	 * @param name
	 * @param description
	 * @param vote
	 */
	public ServiceDAO(int id, String nom, String description, int vote, int idUser)
	{
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.vote = vote;
		this.setIdUser(idUser);
	}

	/**
	 * @return the id
	 */
	public int getId()
	{
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getNom()
	{
		return nom;
	}

	/**
	 * @param name the name to set
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}

	/**
	 * @return the description
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * @return the vote
	 */
	public int getVote()
	{
		return vote;
	}

	/**
	 * @param vote the vote to set
	 */
	public void setVote(int vote)
	{
		this.vote = vote;
	}

	/**
	 * @return the idUser
	 */
	public int getIdUser()
	{
		return idUser;
	}

	/**
	 * @param idUser the idUser to set
	 */
	public void setIdUser(int idUser)
	{
		this.idUser = idUser;
	}
}
