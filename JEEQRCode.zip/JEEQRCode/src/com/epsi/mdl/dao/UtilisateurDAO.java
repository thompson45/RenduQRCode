package com.epsi.mdl.dao;

/**
 * Classe permettant de gérer la DAO des utilisateurs
 * @author Baptiste
 *
 */
public class UtilisateurDAO
{	
	/**
	 * Clé primaire
	 */
	private int id;
	
	/**
	 * Nom de l'utilisateur
	 */
	private String nom;
	
	/**
	 * Mot de passe de l'utilisateur
	 */
	private String mdp;
	
	/**
	 * Constructeur vide de l'utilisateur
	 */
	public UtilisateurDAO()
	{
		super();
	}

	/**
	 * Contructeur paramétré de l'utilisateur
	 * @param id
	 * @param nom
	 * @param mdp
	 */
	public UtilisateurDAO(int id, String nom, String mdp)
	{
		super();
		this.id = id;
		this.nom = nom;
		this.mdp = mdp;
	}
	
	/**
	 * @return the id
	 */
	public int getId()
	{
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id)
	{
		this.id = id;
	}
	/**
	 * @return the nom
	 */
	public String getNom()
	{
		return nom;
	}
	/**
	 * @param name the name to set
	 */
	public void setNom(String nom)
	{
		this.nom = nom;
	}
	/**
	 * @return the mdp
	 */
	public String getMdp()
	{
		return mdp;
	}
	/**
	 * @param mdp the mdp to set
	 */
	public void setMdp(String mdp)
	{
		this.mdp = mdp;
	}
}
